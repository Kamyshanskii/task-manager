package com.taskmanager.controllers;

import com.taskmanager.models.Task;
import com.taskmanager.services.TaskService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @GetMapping
    public ResponseEntity<List<Map<String, Object>>> getAllTasks(Authentication authentication) {
        String username = authentication.getName();
        List<Task> tasks = taskService.getTasksByUsername(username);
        
        List<Map<String, Object>> taskDTOs = tasks.stream().map(task -> {
            Map<String, Object> taskDTO = new HashMap<>();
            taskDTO.put("id", task.getId());
            taskDTO.put("title", task.getTitle());
            taskDTO.put("description", task.getDescription());
            taskDTO.put("completed", task.isCompleted());
            taskDTO.put("userId", task.getUser().getId());
            return taskDTO;
        }).collect(Collectors.toList());
        
        return ResponseEntity.ok(taskDTOs);
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> createTask(
            @RequestBody Map<String, Object> request,
            Authentication authentication) {
        
        String username = authentication.getName();
        String title = (String) request.get("title");
        String description = (String) request.get("description");
        Boolean completed = (Boolean) request.get("completed");
        
        if (title == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Title is required"));
        }
        
        if (completed == null) {
            completed = false;
        }
        
        Task task = taskService.createTask(title, description, completed, username);
        
        Map<String, Object> taskDTO = new HashMap<>();
        taskDTO.put("id", task.getId());
        taskDTO.put("title", task.getTitle());
        taskDTO.put("description", task.getDescription());
        taskDTO.put("completed", task.isCompleted());
        taskDTO.put("userId", task.getUser().getId());
        
        return ResponseEntity.ok(taskDTO);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getTaskById(
            @PathVariable Long id,
            Authentication authentication) {
        
        String username = authentication.getName();
        
        try {
            Task task = taskService.getTaskById(id, username);
            
            Map<String, Object> taskDTO = new HashMap<>();
            taskDTO.put("id", task.getId());
            taskDTO.put("title", task.getTitle());
            taskDTO.put("description", task.getDescription());
            taskDTO.put("completed", task.isCompleted());
            taskDTO.put("userId", task.getUser().getId());
            
            return ResponseEntity.ok(taskDTO);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Map<String, Object>> updateTask(
            @PathVariable Long id,
            @RequestBody Map<String, Object> request,
            Authentication authentication) {
        
        String username = authentication.getName();
        String title = (String) request.get("title");
        String description = (String) request.get("description");
        Boolean completed = (Boolean) request.get("completed");
        
        try {
            Task task = taskService.updateTask(id, title, description, completed, username);
            
            Map<String, Object> taskDTO = new HashMap<>();
            taskDTO.put("id", task.getId());
            taskDTO.put("title", task.getTitle());
            taskDTO.put("description", task.getDescription());
            taskDTO.put("completed", task.isCompleted());
            taskDTO.put("userId", task.getUser().getId());
            
            return ResponseEntity.ok(taskDTO);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteTask(
            @PathVariable Long id,
            Authentication authentication) {
        
        String username = authentication.getName();
        
        try {
            taskService.deleteTask(id, username);
            return ResponseEntity.ok(Map.of("message", "Task deleted successfully"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}
