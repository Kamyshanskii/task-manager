package com.taskmanager.services;

import com.taskmanager.models.Task;
import com.taskmanager.models.User;
import com.taskmanager.repositories.TaskRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TaskService {

    private final TaskRepository taskRepository;
    private final UserService userService;

    public TaskService(TaskRepository taskRepository, UserService userService) {
        this.taskRepository = taskRepository;
        this.userService = userService;
    }

    public List<Task> getTasksByUsername(String username) {
        User user = userService.findByUsername(username);
        return taskRepository.findByUser(user);
    }

    public Task createTask(String title, String description, boolean completed, String username) {
        User user = userService.findByUsername(username);
        Task task = new Task(title, description, completed, user);
        return taskRepository.save(task);
    }

    public Task updateTask(Long id, String title, String description, Boolean completed, String username) {
        User user = userService.findByUsername(username);
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        if (!task.getUser().getId().equals(user.getId())) {
            throw new RuntimeException("Not authorized to update this task");
        }

        if (title != null) {
            task.setTitle(title);
        }
        if (description != null) {
            task.setDescription(description);
        }
        if (completed != null) {
            task.setCompleted(completed);
        }

        return taskRepository.save(task);
    }

    public void deleteTask(Long id, String username) {
        User user = userService.findByUsername(username);
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        if (!task.getUser().getId().equals(user.getId())) {
            throw new RuntimeException("Not authorized to delete this task");
        }

        taskRepository.delete(task);
    }

    public Task getTaskById(Long id, String username) {
        User user = userService.findByUsername(username);
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        if (!task.getUser().getId().equals(user.getId())) {
            throw new RuntimeException("Not authorized to view this task");
        }

        return task;
    }
}
