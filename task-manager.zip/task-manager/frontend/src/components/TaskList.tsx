import React, { useState, useEffect } from 'react';
import { getTasks } from '../api';
import TaskItem from './TaskItem';
import TaskForm from './TaskForm';
import { Task } from '../types';

const TaskList: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchTasks = async () => {
    try {
      setLoading(true);
      const data = await getTasks();
      setTasks(data);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  return (
    <div>
      <h2>Список задач</h2>
      <TaskForm onTaskAdded={fetchTasks} />
      
      {loading ? (
        <p>Загрузка...</p>
      ) : tasks.length === 0 ? (
        <p>Нет задач</p>
      ) : (
        <div>
          {tasks.map((task) => (
            <TaskItem key={task.id} task={task} onTaskUpdated={fetchTasks} />
          ))}
        </div>
      )}
    </div>
  );
};

export default TaskList;
