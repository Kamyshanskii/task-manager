import React, { useState } from 'react';
import { createTask } from '../api';

interface TaskFormProps {
  onTaskAdded: () => void;
}

const TaskForm: React.FC<TaskFormProps> = ({ onTaskAdded }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    await createTask({ title, description, completed: false });
    setTitle('');
    setDescription('');
    onTaskAdded();
  };

  return (
    <div>
      <h3>Добавить задачу</h3>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="title">Название:</label>
          <input
            type="text"
            id="title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="description">Описание:</label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </div>
        <button type="submit">Добавить</button>
      </form>
    </div>
  );
};

export default TaskForm;
