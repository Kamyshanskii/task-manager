import React, { useState } from 'react';
import { Task } from '../types';
import { updateTask, deleteTask } from '../api';

interface TaskItemProps {
  task: Task;
  onTaskUpdated: () => void;
}

const TaskItem: React.FC<TaskItemProps> = ({ task, onTaskUpdated }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [title, setTitle] = useState(task.title);
  const [description, setDescription] = useState(task.description);

  const handleToggleComplete = async () => {
    await updateTask(task.id, { completed: !task.completed });
    onTaskUpdated();
  };

  const handleDelete = async () => {
    await deleteTask(task.id);
    onTaskUpdated();
  };

  const handleUpdate = async () => {
    await updateTask(task.id, { title, description });
    setIsEditing(false);
    onTaskUpdated();
  };

  if (isEditing) {
    return (
      <div style={{ marginBottom: '10px', padding: '10px', border: '1px solid #ddd' }}>
        <div>
          <label htmlFor={`edit-title-${task.id}`}>Название:</label>
          <input
            id={`edit-title-${task.id}`}
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor={`edit-desc-${task.id}`}>Описание:</label>
          <textarea
            id={`edit-desc-${task.id}`}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </div>
        <button onClick={handleUpdate}>Сохранить</button>
        <button onClick={() => setIsEditing(false)}>Отмена</button>
      </div>
    );
  }

  return (
    <div style={{ 
      marginBottom: '10px', 
      padding: '10px', 
      border: '1px solid #000', 
      borderRadius: '8px', 
      backgroundColor: '#fff',
      textAlign: 'left',
    }}>
      <h4 style={{ textDecoration: task.completed ? 'line-through' : 'none' }}>
        {task.title}
      </h4>
      <p>{task.description}</p>
      <div style={{ 
        display: 'flex',
        alignItems: 'center', // Выравниваем элементы по центру по вертикали
        gap: '8px', // Добавляем небольшой отступ между элементами
      }}>
        <label>Выполнено</label>
        <input
          type="checkbox"
          checked={task.completed}
          onChange={handleToggleComplete}
        />
      </div>
      <div style={{ marginTop: '10px' }}>
        <button onClick={() => setIsEditing(true)}>Редактировать</button>
        <button onClick={handleDelete} style={{ marginLeft: '8px' }}>Удалить</button>
      </div>
    </div>
  );
};

export default TaskItem;
