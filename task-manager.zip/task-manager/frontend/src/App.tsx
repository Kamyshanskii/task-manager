import React, { useState, useEffect } from 'react';
import Login from './components/Login';
import Register from './components/Register';
import TaskList from './components/TaskList';
import { logout } from './api';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showLogin, setShowLogin] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      setIsAuthenticated(true);
    }
  }, []);

  const handleLogout = () => {
    logout();
    setIsAuthenticated(false);
  };

  const handleAuthSuccess = () => {
    setIsAuthenticated(true);
  };

  // Стили для фона
  const appStyle: React.CSSProperties = {
    backgroundImage: `url(${require('./backgrounds/background_1.jpg')})`, // Путь к изображению
    backgroundSize: 'cover', // Растягиваем изображение на весь экран
    backgroundPosition: 'center', // Центрируем изображение
    backgroundRepeat: 'no-repeat', // Запрещаем повторение изображения
    minHeight: '100vh', // Минимальная высота на весь экран
    margin: '0', // Убираем отступы
    padding: '0', // Убираем отступы
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  };

  if (!isAuthenticated) {
    return (
      <div style={appStyle}>
        <div style={{ maxWidth: '500px', width: '100%', padding: '20px', borderRadius: '8px', backgroundColor: 'rgba(255, 255, 255, 0.8)' }}>
          {showLogin ? (
            <Login 
              onLoginSuccess={handleAuthSuccess} 
              switchToRegister={() => setShowLogin(false)} 
            />
          ) : (
            <Register 
              onRegisterSuccess={handleAuthSuccess} 
              switchToLogin={() => setShowLogin(true)} 
            />
          )}
        </div>
      </div>
    );
  }

  return (
    <div style={appStyle}>
      <div style={{ maxWidth: '800px', width: '100%', padding: '20px', borderRadius: '8px', backgroundColor: 'rgba(255, 255, 255, 0.8)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
          <h1>Менеджер задач</h1>
          <div>
            <span>Привет, {localStorage.getItem('username')}! </span>
            <button onClick={handleLogout}>Выйти</button>
          </div>
        </div>
        <TaskList />
      </div>
    </div>
  );
};

export default App;
