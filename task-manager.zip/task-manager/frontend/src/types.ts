export interface Task {
  id: number;
  title: string;
  description: string;
  completed: boolean;
  userId: number;
}

export interface User {
  id: number;
  username: string;
  password: string;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  password: string;
}

export interface AuthResponse {
  token: string;
  username: string;
}
