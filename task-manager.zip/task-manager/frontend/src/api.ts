import axios from 'axios';
import { Task, LoginRequest, RegisterRequest, AuthResponse } from './types';

const API_URL = 'http://localhost:8080';

axios.interceptors.request.use(
  config => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  error => {
    return Promise.reject(error);
  }
);

export const login = async (loginRequest: LoginRequest): Promise<AuthResponse> => {
  const response = await axios.post(`${API_URL}/api/auth/login`, loginRequest);
  localStorage.setItem('token', response.data.token);
  localStorage.setItem('username', response.data.username);
  return response.data;
};

export const register = async (registerRequest: RegisterRequest): Promise<AuthResponse> => {
  const response = await axios.post(`${API_URL}/api/auth/register`, registerRequest);
  localStorage.setItem('token', response.data.token);
  localStorage.setItem('username', response.data.username);
  return response.data;
};

export const logout = (): void => {
  localStorage.removeItem('token');
  localStorage.removeItem('username');
};

export const getTasks = async (): Promise<Task[]> => {
  const response = await axios.get(`${API_URL}/api/tasks`);
  return response.data;
};

export const createTask = async (task: Omit<Task, 'id' | 'userId'>): Promise<Task> => {
  const response = await axios.post(`${API_URL}/api/tasks`, task);
  return response.data;
};

export const updateTask = async (id: number, task: Partial<Task>): Promise<Task> => {
  const response = await axios.put(`${API_URL}/api/tasks/${id}`, task);
  return response.data;
};

export const deleteTask = async (id: number): Promise<void> => {
  await axios.delete(`${API_URL}/api/tasks/${id}`);
};
